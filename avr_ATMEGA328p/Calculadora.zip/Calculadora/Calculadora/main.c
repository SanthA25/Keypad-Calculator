#include <avr/io.h>
#include <avr/interrupt.h>

# define F_CPU 16000000UL

# include <util/delay.h>

# define KEY_PORTD PORTD
# define KEY_DDRD DDRD
# define KEY_PIND PIND

# define KEY_PORTB PORTB


// Variables para conocer la posicion de la columna y la fila presionada
unsigned char col_loc, row_loc;


// Caracteres ASSCCI con los que va a trabjar el teclado matricial
unsigned char keypad[4][4] = {	{'/','=','0','.'},
{'*','9','8','7'},
{'-','6','5','4'},
{'+','3','2','1'} };

void UART_init(){
	
	//	UART 9600 baudrate
	UCSR0B = (1<<TXEN0);				         // Activa USART como Trasnmisor
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;						         // Oscilacion de frecuencias

}

// Rutina de interrupcion para PORTD
ISR(PCINT2_vect){

	// Rutina de lectura del teclado
	do{

		KEY_PORTB &= 0x00;                 // Manda a tiera todas las filas
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);       // Leer las columnas

	}while(col_loc != 0xF0);

	do{

		do{

			_delay_ms(75);					// Delay para el debounce
			col_loc = (KEY_PIND & 0xF0);	// Leer las columnas

		}while(col_loc == 0xF0);

		_delay_ms(75);						// Delay para el debounce
		col_loc = (KEY_PIND & 0xF0);		// Leer las columnas

	}while(col_loc == 0xF0);

	while(1){

		KEY_PORTB = 0x0E;                     // Manda a tierra la fila 0
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // Leer columnas

		if(col_loc != 0xF0){                  // Columna detectada

			row_loc = 0;                      // Guarda el # de columna
			break;                            // Sal del ciclo while

		}

		KEY_PORTB = 0x0D;                     // Manda a tierra la fila 1
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // Leer columnas

		if(col_loc != 0xF0){                  // Columna detectada

			row_loc = 1;                      // Guarda el # de columna
			break;                            // Sal del ciclo while

		}

		KEY_PORTB = 0x0B;                     // Manda a tierra la fila 2
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // Leer columnas

		if(col_loc != 0xF0){                  // Columna detectada

			row_loc = 2;                      // Guarda el # de columna
			break;                            // Sal del ciclo while

		}

		KEY_PORTB = 0x07;                     // Manda a tierra la fila 3
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // Leer columnas

		row_loc = 3;                          // Guarda el # de columna
		break;                                // Sal del ciclo while

	}
	

	// Revisa la columna y manda el resultado por USART
	if(col_loc == 0xE0){

		// PORTC = keypad[row_loc][0]; Impresion en leds
		while(!(UCSR0A  & (1<<UDRE0)));	// Esperamos hasta que UDR00 este vacio
		UDR0 = keypad[row_loc][0];		// Mandar dato por UART

		}else if(col_loc == 0xD0){

		// PORTC = keypad[row_loc][1]; Impresion en leds
		while(!(UCSR0A  & (1<<UDRE0)));			 // Esperamos hasta que UDR00 este vacio
		UDR0 = keypad[row_loc][1];		// Mandar dato por UART

		}else  if(col_loc == 0xB0){

		// PORTC = keypad[row_loc][2]; Impresion en leds
		while(!(UCSR0A  & (1<<UDRE0)));			 // Esperamos hasta que UDR00 este vacio
		UDR0 = keypad[row_loc][2];		// Mandar dato por UART

		}else{

		// PORTC = keypad[row_loc][3]; Impresion en leds
		while(!(UCSR0A  & (1<<UDRE0)));			 // Esperamos hasta que UDR00 este vacio
		UDR0 = keypad[row_loc][3];		// Mandar dato por UART

	}

}


	int main(){

	// PORTC  -> output
	DDRC = 0xFF;
	
	UART_init();
	
	PCMSK2 = 0xF0;		// Habilita como interrupcion PORTD[4-7]
	KEY_PORTD = 0xF0;	// PORTD[4-7] PULL-UP activated
	
	KEY_DDRD = 0x00;							// Declaramos columnas como entrada
	DDRB =  0x0F;								// Declaramos las filas como salida
	KEY_PORTB = 0x0F;							// PORTB[0-3] PULL-UP activated
	
	PCICR = (1<<PCIE2);							// Habilita PORTD change interrupcion
	
	sei();										// Llamado a rutina de interrupcion

	while (1);

	return 0;

	}
