#include <avr/io.h>
#include <avr/interrupt.h>

# define F_CPU 16000000UL

# include <util/delay.h>

# define KEY_PORTD PORTD
# define KEY_DDRD DDRD
# define KEY_PIND PIND

# define KEY_PORTB PORTB


// Variables para conocer la posicion de la columna y la fila presionada
unsigned char col_loc, row_loc;


// Caracteres ASSCCI con los que va a trabjar el teclado matricial
unsigned char keypad[4][4] = {	{'/','=','0','.'},
								{'*','9','8','7'},
								{'-','6','5','4'},
								{'+','3','2','1'} };

void UART_init(){

	//	UART 9600 baudrate
	UCSR0B = (1<<TXEN0);				         // Activa USART como Trasnmisor
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
	UBRR0L = 103;						         // Oscilacion de frecuencias

}

// Rutina de interrupcion para PORTD
ISR(PCINT2_vect){

	PORTC = keypad[row_loc][1];
	
	//PCICR &= ~(1<<PCIE2);					//	Desabilitamos interrupcion

	// Rutina de lectura del teclado
	do {
		KEY_PORTB &= 0xF0;                 // ground all rows
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);       // read columns
	}	while(col_loc != 0xF0);

	do {
		do {
			_delay_ms(50);
			col_loc = (KEY_PIND & 0xF0);
		} while(col_loc == 0xF0);
		_delay_ms(50);
		col_loc = (KEY_PIND & 0xF0);
	} while(col_loc == 0xF0);
	
	while(1){	
		KEY_PORTB = 0x0E;                     // ground row 0
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // read columns
		if(col_loc != 0xF0){                  // column detected
			row_loc = 0;                      // save row location
			break;                            // exit while loop
		}

		KEY_PORTB = 0x0D;                     // ground row 1
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // read columns
		if(col_loc != 0xF0) {                 // column detected
			row_loc = 1;                      // save row location
			break;                            // exit while loop
		}

		KEY_PORTB = 0x0B;                     // ground row 2
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // read columns
		if(col_loc != 0xF0){                  // column detected
			row_loc = 2;                      // save row location
			break;                            // exit while loop
		}

		KEY_PORTB = 0x07;                     // ground row 3
		asm("NOP");
		col_loc = (KEY_PIND & 0xF0);          // read columns
		row_loc = 3;                          // save row location
		break;                                // exit while loop
	}

	while(!(UCSR0A  & (1<<UDRE0)));			 // wait until UDR0 is empty

	// Revisa la columna y manda el resultado por USART
	if(col_loc == 0xE0){
		// PORTC = keypad[row_loc][0]; Impresion en leds
		UDR0 = keypad[row_loc][0];		// send to UART
		
	}else if(col_loc == 0xD0){
		// PORTC = keypad[row_loc][1]; Impresion en leds
		UDR0 = keypad[row_loc][1];		// send to UART

	}else  if(col_loc == 0xB0){
		// PORTC = keypad[row_loc][2]; Impresion en leds
		UDR0 = keypad[row_loc][2];		// send to UART

	}else{
		// PORTC = keypad[row_loc][3]; Impresion en leds
		UDR0 = keypad[row_loc][3];		// send to UART

	}

	//PCICR |= (1<<PCIE2);						//	Habilitamos interrupcion*/

}


int main(){
	
	DDRC = 0xFF;								// PORTC  -> output
	UART_init();								// initialize USART
	
	KEY_DDRD = 0xF0;
	KEY_PORTD |= 0xF0;					        // PORTD[4-7] PULL-UP activated (filas)
	DDRB =  0x0F;								// Filas como salida
	KEY_PORTB |= 0x0F;							// PORTB[0-3] PULL-UP activated (columnas)

	PCICR |= (1<<PCIE2);						// PORTD change interruption enable
	PCMSK2 |= 0xF0;								// interruption from PORTD[4-7]

	sei();										// Llamado a rutina de interrupcion
	while (1);
	return 0;

}
